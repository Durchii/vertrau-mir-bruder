# Vertrau-Linker
Flask-Demo zur IP- und Gerätedatenanzeige nach Link-Klick.
